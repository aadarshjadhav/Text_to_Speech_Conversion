from tkinter import *
import tkinter.messagebox
from tkinter import filedialog
from tkinter import ttk
from tkinter.ttk import *
from ttkthemes import themed_tk as tk

from gtts import gTTS

from mutagen.mp3 import MP3
from pygame import mixer

import random# fo name random name for audio file
import time #for current time and total time
import threading #distributing processor work
import os

# Basic GUI
root = tk.ThemedTk()
root.get_themes()
root.set_theme("radiance")
root.title('Text To Speech Converter')
root.iconbitmap(r'icons/gui_icon.ico')
root.resizable(False, False)
mixer.init()  # initializing

# Root Window - Statusbar Left_frame Right_frame
# Left_Frame - Selecting Text file
# Right_Frame - Top_Frame Middle_Frame Bottom_Frame (Music Player , TTS converter)

# Creating a Status bar

statusbar = ttk.Label(root, text="Welcome To Python Project", relief=SUNKEN, anchor=W, font='Arial 10 italic')
statusbar.pack(side=BOTTOM, fill=X)  # Arrange the status bar in root window ??????

# Creating Left Frame
Left_Frame = Frame(root)
Left_Frame.pack(side=LEFT, padx=30, pady=30)

txt_listbox = Listbox(Left_Frame) #??????????????????????
txt_listbox.pack()
file_list = []

Right_Frame = Frame(root)
Right_Frame.pack(pady=30)

# Creating Top Frame for Current Time and Total Length Label
top_frame = Frame(Right_Frame)
top_frame.pack()

# Creating Middle frame for Play Pause And Stop button ???????????
middle_frame = Frame(Right_Frame)
middle_frame.pack(padx=30, pady=10)

# Creating Bottom Frame for Rewind Delete Mute Button

bottom_frame = Frame(Right_Frame)
bottom_frame.pack()

# Menu Bar
menubar = Menu(root)  # Creates Empty Menu bar
root.config(menu=menubar)  # To keep Menu Bar at the top?????????

# Creating Sub-Menu
def abt_us():  # Showing About Us  Info
    f = open('abt_us.txt', "r") #content of the file is assigned to f in read mode
    tkinter.messagebox.showinfo("About Us", f.read())  #shows  message window about us information
    f.close()

def del_op_file():  # Deleting Output File
    try:
        mixer.quit()
        os.remove(random_file) #file name of the random file created  is passed in this remove function
        tkinter.messagebox.showinfo("Info", "Output File Deleted Successfully.")
        statusbar['text'] = "Audio File Deleted"
        current_time_label['text'] = "Current Time - 00:00"
        length_label['text'] = "Total Length - 00:00"

    except:
        tkinter.messagebox.showerror("Error", "File Not Found !!!")

# file_list contains full path + filename
# txt_listbox contains filename
# full path + filename is required to play music in play_btn  function

def browse_file():  # Browsing a File
    global filename_path # global variable name
    filename_path = filedialog.askopenfilename() #askopenfile function is used to browse the location of the file
    add_to_list(filename_path)

def add_to_list(filename):
    filename = os.path.basename(filename) #??????????
    index = 0
    txt_listbox.insert(index, filename)
    file_list.insert(index, filename_path)
    index += 1
    statusbar['text'] = "Text File Added to List"

# Creating Sub-Menu

subMenu = Menu(menubar, tearoff=0)  # creates subMenu tearoff????????????????????????????????????
menubar.add_cascade(label="File", menu=subMenu)  # Adding File option in Menu bar
subMenu.add_command(label="Open", command=browse_file)  # Adding option in sub Menu
subMenu.add_command(label="Exit", command=root.destroy)  # Adding option in sub Menu

subMenu = Menu(menubar, tearoff=0)
menubar.add_cascade(label="Help", menu=subMenu)  # Adding Help option in Menu bar
subMenu.add_command(label="About Us", command=abt_us)  # Adding option in sub Menu

# Label & File Details & ListBox

length_label = ttk.Label(Right_Frame, text="Total Length - 00:00")
length_label.pack(pady=5) #pady position add y-axis

current_time_label = ttk.Label(Right_Frame, text="Current Time - 00:00", relief=GROOVE) #grove??????????????
current_time_label.pack() #nopady here??????????????????????????????????

# Functions and GUI

# Show Audio Details
def show_details():
    # Calculating The Length of Audio File
    a = MP3(random_file)
    total_length = a.info.length
    mins, secs = divmod(total_length, 60)  # div - total_length/60 , mod - total_length%60
    mins = round(mins)
    secs = round(secs)
    timeformat = '{:02d}:{:02d}'.format(mins, secs)
    length_label['text'] = "Total Length - " + timeformat

    t1 = threading.Thread(target=cur_len, args=(total_length,)) #threading ????????????????????????????
    t1.start()


def cur_len(t):             # Showing Current Time of Audio file #where did t come from???????????????????????????????????
    global len
    global paused
    len = 0
    while len != t and mixer.music.get_busy():
        if paused:
            continue
        else:
            mins, secs = divmod(len, 60)  # div - t / 60 , mod - t % 60
            mins = round(mins)
            secs = round(secs)
            timeformat = '{:02d}:{:02d}'.format(mins, secs)
            current_time_label['text'] = "Current Time - " + timeformat
            time.sleep(1) #sleep()????????????????????????????????????????????????????
            len = len + 1

# Play Button Function
def play_btn():
    global paused
    if paused:
        mixer.music.unpause()
        statusbar['text'] = "Audio Resumed"
        paused = False
    else:
        try:
            mixer.music.load(random_file)
            mixer.music.play()
            statusbar['text'] = "Playing Audio For Text : " + " " + os.path.basename(file_for_conversion)
            show_details()
        except:
            tkinter.messagebox.showerror("Error", "No Audio File To Play")

# Stop Button Function
def stop_btn():
    mixer.music.stop()
    os.remove(random_file)
    statusbar['text'] = "Audio Stopped"

# Pause Button Function
paused = False

def pause_btn():
    global paused
    paused = True
    mixer.music.pause()
    statusbar['text'] = "Audio Paused"

# Rewind Button Function
def rewind_btn():
    mixer.music.rewind()
    statusbar['text'] = "Audio Rewind"

# Mute Button Function
var_mute = False

def mute_btn():
    global var_mute
    if var_mute:  # Unmute
        var_mute = False
        volctrl.set(70)
        mixer.music.set_volume(0.7)
        mutebtn.config(image='icons/vol_icon')     #??????????????????????
        statusbar['text'] = "Audio UnMute"
    else:  # Mute
        var_mute = True
        volctrl.set(0)
        mixer.music.set_volume(0)
        mutebtn.config(image='icons/mute_icon')
        statusbar['text'] = "Audio Mute"

#  Convert Function
def convr():
    global data
    global random_file
    global file_for_conversion
    selected_file = txt_listbox.curselection()
    selected_file = int(selected_file[0]) #????????????????????????????????????????????????
    file_for_conversion = file_list[selected_file]
    statusbar['text'] = "Converting..."
    r1 = random.randint(1, 100)
    r2 = random.randint(1, 100)
    random_file = str(r2) + "output_audio_file" + str(r1) + ".mp3"  # Random Filename created

    f = open(file_for_conversion, "r")
    t = gTTS(text=f.read(), lang='en', slow=False)  # Conversion of text to speech function gTTS
    t.save(random_file)
    tkinter.messagebox.showinfo("Info", "Text to Speech Conversion Successfull ")
    statusbar['text'] = "Finished Conversion"
    f.close()

def set_vol(val):
    volume = float(val) / 100
    mixer.music.set_volume(volume)


# Buttons

add_btn = ttk.Button(Left_Frame, text="Add", command=browse_file)
add_btn.pack(side=LEFT)

def delete_func():
    selected_file = txt_listbox.curselection()
    selected_file = int(selected_file[0])
    txt_listbox.delete(selected_file)
    file_list.pop(selected_file)
    statusbar['text'] = "Text File Deleted from List"


del_btn = ttk.Button(Left_Frame, text="Delete", command=delete_func)
del_btn.pack(side=LEFT)

convr_btn = ttk.Button(top_frame, text='Convert', command=convr)  # Convert Button
convr_btn.pack(pady=10)

# Play Button

play_icon = PhotoImage(file='icons/play_icon.png')
pbtn = ttk.Button(middle_frame, image=play_icon, command=play_btn)
pbtn.grid(row=0, column=0, padx=10)

# Pause Button
pause_icon = PhotoImage(file='icons/pause_icon.png')
paubtn = ttk.Button(middle_frame, image=pause_icon, command=pause_btn)
paubtn.grid(row=0, column=1, padx=10)

# Stop Button
stop_icon = PhotoImage(file='icons/stop_icon.png')
stpbtn = ttk.Button(middle_frame, image=stop_icon, command=stop_btn)
stpbtn.grid(row=0, column=2, padx=10)

# Rewind button
rewind_icon = PhotoImage(file='icons/rewind_icon.png')  # Rewind Button
rewindbtn = ttk.Button(bottom_frame, image=rewind_icon, command=rewind_btn)
rewindbtn.grid(row=0, column=0, padx=10)

# Mute / Volume Button
mute_icon = PhotoImage(file='icons/speakeroff_icon.png')  # Mute Button Img
vol_icon = PhotoImage(file='icons/speakeron_icon.png')  # Volume Button Img
mutebtn = ttk.Button(bottom_frame, image=vol_icon, command=mute_btn)
mutebtn.grid(row=0, column=1, padx=10)

# Delete Output file Button
trash_icon = PhotoImage(file='icons/delete_icon.png')  # Mute Button Img
delbtn = ttk.Button(bottom_frame, image=trash_icon, command=del_op_file)
delbtn.grid(row=0, column=2, padx=10)

# Volume Controller
volctrl = ttk.Scale(bottom_frame, from_=0, to=100, orient=HORIZONTAL, command=set_vol)  # Volume Controller
volctrl.set(70)
mixer.music.set_volume(0.7)
volctrl.grid(row=0, column=3, padx=30)

def on_closing():
    if tkinter.messagebox.askokcancel("Quit", "Do you really wish to quit?"):
        try:
            mixer.quit()
            for x in os.listdir():
                if x.endswith(".mp3"):
                    os.remove(x)
            root.destroy()
        except:
            mixer.quit()
            root.destroy()

root.protocol("WM_DELETE_WINDOW", on_closing)

root.mainloop()
